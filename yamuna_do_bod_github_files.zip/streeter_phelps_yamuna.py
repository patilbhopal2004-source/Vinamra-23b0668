import numpy as np
import pandas as pd
from scipy.optimize import minimize
import matplotlib.pyplot as plt

# 1. Observed River Data (DPCC 08.10.2024, Annexure-6)
stations = pd.DataFrame({
    'station': ['Wazirabad', 'ISBT Bridge', 'ITO Bridge', 'Nizamuddin Bridge', 'Okhla Barrage', 'Asgarpur'],
    'km': [0.0, 5.2, 11.0, 15.8, 22.8, 32.5],
    'BOD_obs': [9.0, 35.0, 24.0, 31.0, 29.0, 44.0],
    'DO_obs': [4.2, 0.0, 2.1, 0.0, 1.1, 0.0]
})

# 2. Active Drain Inflows (DPCC/DJB 08.10.2024, Annexures 3 & 7)
drains_oct24 = pd.DataFrame([
    {'name': 'Najafgarh Drain', 'km': 0.5, 'Q_mld': 2056.32, 'BOD': 60.0, 'DO': 0.5, 'reach': 'Wazirabad-ISBT'},
    {'name': 'Sonia Vihar Drain', 'km': 1.2, 'Q_mld': 27.24, 'BOD': 52.0, 'DO': 1.0, 'reach': 'Wazirabad-ISBT'},
    {'name': 'ISBT Drain', 'km': 5.4, 'Q_mld': 43.20, 'BOD': 76.0, 'DO': 0.5, 'reach': 'ISBT-ITO'},
    {'name': 'Shastri Park Drain', 'km': 6.8, 'Q_mld': 5.45, 'BOD': 46.0, 'DO': 1.0, 'reach': 'ISBT-ITO'},
    {'name': 'Power House / Delhi Gate Drain', 'km': 10.2, 'Q_mld': 122.58, 'BOD': 50.0, 'DO': 1.0, 'reach': 'ISBT-ITO'},
    {'name': 'SEN Nursing Home Drain', 'km': 12.1, 'Q_mld': 43.20, 'BOD': 56.0, 'DO': 0.5, 'reach': 'ITO-Nizamuddin'},
    {'name': 'Barapulla Drain', 'km': 17.0, 'Q_mld': 145.15, 'BOD': 68.0, 'DO': 0.5, 'reach': 'Nizamuddin-Okhla'},
    {'name': 'Maharani Bagh Drain', 'km': 18.4, 'Q_mld': 30.24, 'BOD': 48.0, 'DO': 0.5, 'reach': 'Nizamuddin-Okhla'},
    {'name': 'Shahdara Drain', 'km': 23.5, 'Q_mld': 475.20, 'BOD': 100.0, 'DO': 0.5, 'reach': 'Okhla-Asgarpur'},
    {'name': 'Abul Fazal Drain', 'km': 24.2, 'Q_mld': 7.00, 'BOD': 54.0, 'DO': 0.5, 'reach': 'Okhla-Asgarpur'},
    {'name': 'Jaitpur Drain', 'km': 25.0, 'Q_mld': 5.68, 'BOD': 68.0, 'DO': 0.5, 'reach': 'Okhla-Asgarpur'},
    {'name': 'Tuglakabad Drain', 'km': 25.2, 'Q_mld': 25.05, 'BOD': 52.0, 'DO': 0.5, 'reach': 'Okhla-Asgarpur'},
])

def run_streeter_phelps(
    Q_wazirabad_mld=10.0, BOD_wazirabad=9.0, DO_wazirabad=4.2,
    k1_20=0.294, k2_20=0.300, k_settle=0.800, T_water=27.0,
    v_km_day=12.0, agracanal_diversion_frac=0.80,
    ito_weir_eff=0.28, okhla_weir_eff=0.16, drain_df=None, dx=0.1
):
    if drain_df is None:
        drain_df = drains_oct24.copy()
    k1 = k1_20 * (1.047 ** (T_water - 20.0))
    k2 = k2_20 * (1.024 ** (T_water - 20.0))
    DO_sat = 14.652 - 0.41022*T_water + 0.007991*(T_water**2) - 0.000077774*(T_water**3)

    x_grid = np.round(np.arange(0.0, 32.5 + dx, dx), 2)
    Q_arr, BOD_arr, DO_arr = np.zeros_like(x_grid), np.zeros_like(x_grid), np.zeros_like(x_grid)
    Q, L, C = Q_wazirabad_mld, BOD_wazirabad, DO_wazirabad

    drain_map = {}
    for _, row in drain_df.iterrows():
        gx = round(round(row['km'] / dx) * dx, 2)
        drain_map.setdefault(gx, []).append(row)

    for i, x in enumerate(x_grid):
        if x in drain_map:
            for d in drain_map[x]:
                Qd = d['Q_mld']
                if Qd > 0:
                    L = (Q * L + Qd * d['BOD']) / (Q + Qd)
                    C = (Q * C + Qd * d['DO']) / (Q + Qd)
                    Q += Qd
        if np.isclose(x, 10.9):
            C += ito_weir_eff * max(0.0, DO_sat - C)
        if np.isclose(x, 22.8):
            C += okhla_weir_eff * max(0.0, DO_sat - C)
            Q *= (1.0 - agracanal_diversion_frac)

        Q_arr[i], BOD_arr[i], DO_arr[i] = Q, L, C
        if i < len(x_grid) - 1:
            dt = dx / v_km_day
            kr = k1 + (k_settle if x < 5.2 else 0.0)
            D0 = DO_sat - C
            L_next = L * np.exp(-kr * dt)
            D_next = (k1 * L / (k2 - kr)) * (np.exp(-kr * dt) - np.exp(-k2 * dt)) + D0 * np.exp(-k2 * dt)
            L, C = L_next, np.clip(DO_sat - D_next, 0.0, DO_sat)

    return pd.DataFrame({'km': x_grid, 'Q_mld': Q_arr, 'BOD': BOD_arr, 'DO': DO_arr})

def calibrate_model():
    obs_km = stations['km'].values
    obs_bod = stations['BOD_obs'].values
    obs_do = stations['DO_obs'].values

    def loss(params):
        k1_20, k2_20, v_km_day, k_settle = params
        res = run_streeter_phelps(
            Q_wazirabad_mld=10.0, k1_20=k1_20, k2_20=k2_20, v_km_day=v_km_day, k_settle=k_settle
        )
        mod_bod = np.interp(obs_km, res['km'], res['BOD'])
        mod_do = np.interp(obs_km, res['km'], res['DO'])
        err_bod = np.mean(((mod_bod[1:] - obs_bod[1:]) / 5.0) ** 2)
        err_do = np.mean(((mod_do[1:] - obs_do[1:]) / 0.5) ** 2)
        return err_bod + err_do

    opt = minimize(
        loss,
        x0=[0.45, 0.65, 18.0, 0.40],
        bounds=[(0.20, 0.70), (0.30, 1.20), (12.0, 30.0), (0.0, 0.80)],
        method='L-BFGS-B'
    )
    return opt.x

def run_all_scenarios(k1_c, k2_c, v_c, ks_c):
    scenarios = {}
    scenarios['Baseline (Current)'] = run_streeter_phelps(
        Q_wazirabad_mld=10.0, k1_20=k1_c, k2_20=k2_c, v_km_day=v_c, k_settle=ks_c
    )

    d_l1 = drains_oct24.copy()
    d_l1.loc[d_l1['name'] == 'Najafgarh Drain', 'BOD'] = 10.0
    d_l1.loc[d_l1['name'] == 'Najafgarh Drain', 'DO'] = 4.0
    scenarios['Int. 1: Najafgarh STP Upgrade'] = run_streeter_phelps(
        Q_wazirabad_mld=10.0, k1_20=k1_c, k2_20=k2_c, v_km_day=v_c, k_settle=ks_c, drain_df=d_l1
    )

    d_l2 = drains_oct24.copy()
    mask_l2 = d_l2['name'] != 'Najafgarh Drain'
    d_l2.loc[mask_l2, 'BOD'] = 10.0
    d_l2.loc[mask_l2, 'DO'] = 4.0
    scenarios['Int. 2: Eastern/Central Drains STP'] = run_streeter_phelps(
        Q_wazirabad_mld=10.0, k1_20=k1_c, k2_20=k2_c, v_km_day=v_c, k_settle=ks_c, drain_df=d_l2
    )

    scenarios['Int. 3: E-Flow Release (23 cumecs)'] = run_streeter_phelps(
        Q_wazirabad_mld=1987.2, BOD_wazirabad=4.0, DO_wazirabad=7.1,
        k1_20=k1_c, k2_20=k2_c*1.15, v_km_day=17.5, k_settle=ks_c*0.5
    )

    d_l4 = drains_oct24.copy()
    d_l4['BOD'] = 10.0
    d_l4['DO'] = 5.0
    scenarios['Int. 4: Integrated (STP + E-Flow + Aeration)'] = run_streeter_phelps(
        Q_wazirabad_mld=1987.2, BOD_wazirabad=4.0, DO_wazirabad=7.1,
        k1_20=k1_c, k2_20=k2_c*1.25, v_km_day=17.5, k_settle=ks_c*0.5,
        ito_weir_eff=0.45, okhla_weir_eff=0.45, drain_df=d_l4
    )
    return scenarios

if __name__ == '__main__':
    k1_c, k2_c, v_c, ks_c = calibrate_model()
    print(f"Calibrated: k1_20={k1_c:.3f}/d, k2_20={k2_c:.3f}/d, v={v_c:.2f} km/d, k_settle={ks_c:.3f}/d")
    scenarios = run_all_scenarios(k1_c, k2_c, v_c, ks_c)
    drains_oct24.to_csv('yamuna_oct2024_drains.csv', index=False)

    base_df = scenarios['Baseline (Current)']
    comp = stations.copy()
    comp['Q_mod_MLD'] = np.interp(comp['km'], base_df['km'], base_df['Q_mld']).round(1)
    comp['BOD_mod'] = np.interp(comp['km'], base_df['km'], base_df['BOD']).round(2)
    comp['DO_mod'] = np.interp(comp['km'], base_df['km'], base_df['DO']).round(2)
    comp.to_csv('yamuna_calibration_results.csv', index=False)

    cost_map = {
        'Baseline (Current)': 0,
        'Int. 1: Najafgarh STP Upgrade': 3085,
        'Int. 2: Eastern/Central Drains STP': 1395,
        'Int. 3: E-Flow Release (23 cumecs)': 450,
        'Int. 4: Integrated (STP + E-Flow + Aeration)': 4930
    }
    rows = []
    for name, df in scenarios.items():
        sub = df[df['km'] >= 0.5]
        rows.append({
            'Scenario': name,
            'BOD_ITO': round(np.interp(11.0, df['km'], df['BOD']), 1),
            'BOD_Okhla': round(np.interp(22.8, df['km'], df['BOD']), 1),
            'BOD_Asgarpur': round(np.interp(32.5, df['km'], df['BOD']), 1),
            'Mean_BOD': round(sub['BOD'].mean(), 1),
            'DO_ITO': round(np.interp(11.0, df['km'], df['DO']), 2),
            'DO_Nizamuddin': round(np.interp(15.8, df['km'], df['DO']), 2),
            'DO_Okhla': round(np.interp(22.8, df['km'], df['DO']), 2),
            'Mean_DO': round(sub['DO'].mean(), 2),
            'Hypoxic_Stretch_%': round((sub['DO'] < 1.0).mean() * 100.0, 1),
            'DO>=5_Compliance_%': round((sub['DO'] >= 5.0).mean() * 100.0, 1),
            'Indicative_CapEx_Cr': cost_map[name]
        })
    summary_df = pd.DataFrame(rows)
    summary_df.to_csv('yamuna_intervention_summary.csv', index=False)
    print(summary_df.to_string(index=False))
